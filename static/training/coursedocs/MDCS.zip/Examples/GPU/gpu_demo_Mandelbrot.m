%% Artemis GPU demo code, based on Matlab's Mandelbrot demo

% Illustrating Three Approaches to GPU Computing: The Mandelbrot Set
% This example shows how a simple, well-known mathematical problem, the 
% Mandelbrot Set, can be expressed in MATLAB(R) code.  Using 
% Parallel Computing Toolbox(TM) this code is then adapted to make use of
% GPU hardware in three ways:
%
% # Using the existing algorithm but with GPU data as input
% # Using |arrayfun| to perform the algorithm on each element independently
% # Using the MATLAB/CUDA interface to run some existing CUDA/C++ code

% Copyright 2011-2016 The MathWorks, Inc.

set(0,'DefaultAxesFontSize',15)

%% Setup
% The values below specify a highly zoomed part of the Mandelbrot Set in
% the valley between the main cardioid and the p/q bulb to its left.  
%
% A 1000x1000 grid of real parts (X) and imaginary parts (Y) is created
% between these limits and the Mandelbrot algorithm is iterated at each
% grid location. For this particular location 500 iterations will be enough
% to fully render the image.
maxIterations = 500;
gridSize = 1000;
xlim = [-0.748766713922161, -0.748766707771757];
ylim = [ 0.123640844894862,  0.123640851045266];

%% The Mandelbrot Set in MATLAB
% The Mandelbrot set consists of complex numbers z0 for which the iterative series
% _{ z(0) = 0
%  { z(n+1) = z(n)^2 + z0
% remains bounded. This will be true if the limit of the magnitude || z(n->Inf) || <= 2. 

% Record start time
t = tic();

% Initialise the domain (a 2D grid in complex plane)
x = linspace( xlim(1), xlim(2), gridSize );
y = linspace( ylim(1), ylim(2), gridSize );
[xGrid,yGrid] = meshgrid( x, y );


z0 = xGrid + 1i*yGrid;
count = ones( size(z0) );

% Iterate!
% We will count the iteration after which it becomes evident that a series is
% unbounded.
z = z0; % Starting from iteration 1 ( z(0)=0 => z(1)=z0 )
for n = 1:maxIterations
    z = z.*z + z0;
    inside = abs( z )<=2;
    count = count + inside;  
end
count = log( count ); % Use log to compress the range, for better plotting

% Show
cpuTime = toc( t );
fig1 = figure('visible','off'); clf
fig1.Position = [200 200 700 600];
imagesc( x, y, count ), colorbar
colormap( [jet();flipud( jet() );0 0 0] );
axis off
title( sprintf( '%1.2f secs (without GPU)', cpuTime ) );
saveas(fig1,'CPU.png')

%% Using |gpuArray|
% When MATLAB encounters data on the GPU, calculations with that data are
% performed on the GPU. 

% Record start time
t = tic();

% Initialise the domain (a 2D grid in complex plane)
% This time we initialise ON the GPU with 'gpuArray' <-- Matlab will then do all
% computations on this data on the GPU
x = gpuArray.linspace( xlim(1), xlim(2), gridSize );
y = gpuArray.linspace( ylim(1), ylim(2), gridSize );
[xGrid,yGrid] = meshgrid( x, y );

z0 = complex( xGrid, yGrid );
count = ones( size(z0), 'gpuArray' );

% Iterate!
% We will count the iteration aterwhich it becomes evident that a series is
% unbounded.
z = z0; % Starting from iteration 1 ( z(0)=0 => z(1)=z0 )
for n = 1:maxIterations
    z = z.*z + z0;
    inside = abs( z )<=2;
    count = count + inside;  
end
count = log( count ); % Use log to compress the range, for better plotting

% Show
count = gather( count ); % Fetch the data back from the GPU
naiveGPUTime = toc( t );
fig2 = figure('visible','off'); clf
fig2.Position = [200 200 700 600];
imagesc( x, y, count ), colorbar
colormap( [jet();flipud( jet() );0 0 0] );
axis off
title( sprintf( '%1.3f secs (naive GPU) = %1.1fx faster', ...
    naiveGPUTime, cpuTime/naiveGPUTime ) )
saveas(fig2,'GPU.png')


%% Element-wise Operation
% Noting that the algorithm is operating equally on every element of the
% input, we can place the code in a helper function and call it using
% 'gpuArray.arrayfun'.  For GPU array inputs, the function used with 
% |arrayfun| gets compiled into native GPU code.

%     function count = GPU_mandelbrot(x0,y0,maxIterations)
%         z0 = complex(x0,y0);
%         z = z0;
%         count = 1;
%         while (count <= maxIterations) && (abs(z) <= 2)
%             count = count + 1;
%             z = z*z + z0;
%         end
%         count = log(count);   % Use log to compress the range, for better plotting
%     end

% Note that an early abort has been introduced (the  && (abs(z) <= 2) condition)
% because this function processes only a single element. 
% For most views of the Mandelbrot Set a significant number of elements
% stop very early and this can save a lot of processing.
% The |for| loop has also been replaced by a |while| loop
% because they are usually more efficient. This function makes no mention
% of the GPU and uses no GPU-specific features - it is standard MATLAB
% code.
%
% Using |arrayfun| means that instead of many thousands of calls to
% separate GPU-optimized operations (at least 6 per iteration), we make one
% call to a parallelized GPU operation that performs the whole calculation.
% 
% This significantly reduces overhead.

% Record start time
t = tic();

% Initialise the domain (a 2D grid in complex plane)
% This time we initialise ON the GPU with 'gpuArray' <-- Matlab will then do all
% computations on this data on the GPU
x = gpuArray.linspace( xlim(1), xlim(2), gridSize );
y = gpuArray.linspace( ylim(1), ylim(2), gridSize );
[xGrid,yGrid] = meshgrid( x, y );

% Calculate
count = arrayfun( @GPU_mandelbrot, ...
                  xGrid, yGrid, maxIterations );

% Show
count = gather( count ); % Fetch the data back from the GPU
gpuArrayfunTime = toc( t );
fig3 = figure('visible','off'); clf
fig3.Position = [200 200 700 600];
imagesc( x, y, count ), colorbar
colormap( [jet();flipud( jet() );0 0 0] );
axis off
title( sprintf( '%1.3f secs (GPU arrayfun) = %1.1fx faster', ...
    gpuArrayfunTime, cpuTime/gpuArrayfunTime ) );
saveas(fig3,'GPU_array.png')


%% GPU Mandelbrot evaluation function
    function count = GPU_mandelbrot(x0,y0,maxIterations)
        z0 = complex(x0,y0);
        z = z0;
        count = 1;
        while (count <= maxIterations) && (abs(z) <= 2)
            count = count + 1;
            z = z*z + z0;
        end
        count = log(count);  % Use log to compress the range, for better plotting
    end