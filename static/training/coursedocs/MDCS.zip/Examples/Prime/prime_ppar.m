function [total, time, attrib] = prime_ppar(lower, upper)
%% prime_ppar returns the number of primes between lower and upper bounds
% Manually parallelised version - Single Program Muliple Data (SPMD)

  % Get parpool info
  p = gcp();
  numWorkers = p.NumWorkers;
  
% Begin SPMD block
ticBytes(gcp);

spmd (numWorkers)
  % to store the sum for the local labindex:
  localsum = 0;

  % calculate the lower and upper bounds for this labindex
  % note: labindex goes from 1..n, unlike MPI rank which is 0-based
  chunksize = idivide(int32(upper-lower), numlabs);
  mylower = lower + ((labindex-1) * (chunksize+1));
  myupper = mylower + chunksize;
  myupper = min(myupper, upper);

%   X = lower:upper;
%   cuts = find(labindex * sum(X)/numlabs <= cumsum(X) ,1,'first');
%   cuts = [0 gop(@horzcat,cuts)];
%   myupper = int32( cuts(labindex+1)   );
%   mylower = int32( 1 + cuts(labindex) );
  
  % Record which workers performed which iterations
  attrib = cell(numel(lower:upper),1);

  % start a timer to benchmark the main loop
  ticID = tic;

  %To check for prime nature, test whether any number below the value 
  %of the current number is a factor.
  %If it is a prime add a counter to 'total' otherwise move on.
  
  %The main loop.
  %Check every number between the lower and upper bounds.
  for i = mylower : myupper
        
    if i == mylower
        fprintf('I am lab %i, testing %i to %i\n',labindex,mylower,myupper)
    end

    %Set a flag for prime nature
        isprime = 1; % TRUE

    % Deal with the case of Prime Numbers 1 and 2
    if i <= 1
        isprime = 0; % FALSE
    elseif i == 2
        isprime = 1; % TRUE
        
    % Now go through all other numbers
    else
        % Start at 2 and test all numbers up to the current number
        for j = 2 : i-1
            % Check if the numbers divide without remainder (i.e. are
            % factors)
            if ( mod (i, j) == 0 )
                isprime = 0; %FALSE
%                 break
            end
        end
    end
    
    %Now check the flag to see if we increment the counter or not
    if isprime == 1
        % here we increment just our local sum
        localsum = localsum + 1;
        attrib{i} = labindex;
    end

  end
  
%   fprintf('Localsum = %i.\n',localsum)
%   end
  
  % stop the timer
  % concatenate all comp times to a single variable on lab 1
  time = gop(@horzcat,toc(ticID),1);
  
  % update the global total based on all the localsums, sum on lab 1
  total = gplus(localsum,1);
  
  % Note attributions, sum on lab 1
  attrib = gplus(hist([attrib{:}],1:numlabs),1);
  
end % SPMD block
fprintf('\n')
tocBytes(gcp)

% Output reaults back to Matlab client
total = total{1};   % retrieve lab 1's value
attrib = attrib{1}; % retrieve lab 1's value
time = [time{:}];   % retrieve all labs' values and concatenate

end