%primeProcess.m
%A script to call various versions of the prime function both locally and
%using remote HPC.

%Set the upper and lower bounds to search through
upper = 10000;
lower = 1;

%% LOCAL SINGLE CORE
fprintf('Running locally Single Core...\n')
[nPrimes1,t1] = prime(lower, upper);
fprintf('%d primes / %d integers: %f seconds\n',nPrimes1, upper, t1)

%% Start local parallel pool (if none open)
% (your default cluster profile may now be Artemis MDCS, and we don't want
% to open a pool there!!)
mypool = gcp('nocreate');
if isempty(mypool), mypool = parpool('local',4); end

%% LOCAL MULTI CORE
fprintf('Running locally Multi Core - PARFOR ...\n')
[nPrimes2,t2] = prime_par(lower, upper);
fprintf('%d primes / %d integers: %f seconds\n\n',nPrimes2, upper, t2)

%% LOCAL MULTI CORE Manual (SMPD)
fprintf('Running locally Multi Core - SMPD ...\n')
[nPrimes3,t3] = prime_ppar(lower, upper);
fprintf('%d primes / %d integers: %f seconds\n\n',nPrimes3, upper, max(t3))

%% REMOTE MULTI CORE automatic (PARFOR)
fprintf('Running Remotely Multi Core - PARFOR ...\n')

tic %Let's time how long the entire process takes

job1 = batch(...
    @prime_par,...         %Function Name to send to HPC
    3,...                   %Number of variables returned by fcn
    {lower,upper},...       %Inputs to use in function
    'Profile','Artemis',... %Name of the Cluster Profile to use
    'Pool',11,...           %Number of cpus to use in pool (max of 11)
    'CurrentFolder','.');   % Don't attempt to change into cwd

wait(job1)  %This prevents us from using the terminal while we wait for 
            %results from the batch job. Remove this to continue working.
            
%Get the results from the returned job
jobOut = fetchOutputs(job1);
nPrimes4 = jobOut{1};
t4 = jobOut{2};

%Print the results
fprintf('%d primes / %d integers: %f seconds computation time.\n',...
    nPrimes4, upper,t4)
fprintf('Total job submission and queue-wait = %f s.\n\n',toc) %Finish timing of the entire process.
            
%% REMOTE MULTI CORE Manual (SPMD)
fprintf('Running Remotely Multi Core - SPMD ...\n')

tic %Let's time how long the entire process takes

job2 = batch(...
    @prime_ppar,...         %Function Name to send to HPC
    3,...                   %Number of variables returned by fcn
    {lower,upper},...       %Inputs to use in function
    'Profile','Artemis',... %Name of the Cluster Profile to use
    'Pool',11,...           %Number of cpus to use in pool (max of 11)
    'CurrentFolder','.');   % Don't attempt to change into cwd

wait(job2)  %This prevents us from using the terminal while we wait for 
            %results from the batch job. Remove this to continue working.

%Get the results from the returned job
jobOut = fetchOutputs(job2);
nPrimes5 = jobOut{1};
t5 = jobOut{2};

%Print the results
fprintf('%d primes / %d integers: %f seconds computation time.\n',...
    nPrimes5, upper, max(t5))
fprintf('Total job submission and queue-wait = %f s.\n\n',toc) %Finish timing of the entire process.


