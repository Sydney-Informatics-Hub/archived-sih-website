function [total, time] = prime(lower, upper)
%% PRIME returns the number of primes between lower and upper bounds

  %Create a counter for primes
  total = 0;

  % start a timer to benchmark the main loop
  ticID = tic;


  %To check for prime nature, test whether any number below the value 
  %of the current number is a factor.
  %If it is a prime add a counter to 'total' otherwise move on.
  
  %The main loop.
  %Check every number between the lower and upper bounds.
  for i = lower : upper
    %Set a flag for prime nature
    isprime = 1; % TRUE

    % Deal with the case of Prime Numbers 1 and 2
    if i <= 1
        isprime = 0; % FALSE
    elseif i == 2
        isprime = 1; % TRUE
        
    % Now go through all other numbers
    else
        % Start at 2 and test all numbers up to the current number
        for j = 2 : i-1
            % Check if the numbers divide without remainder (i.e. are
            % factors)
            if ( mod (i, j) == 0 )
                isprime = 0; %FALSE
            end
        end
    end
    
    %Now check the flag to see if we increment the counter or not
    if isprime == 1
        total = total + 1;
    end

  end

  % stop the timer
  time = toc(ticID);

end