function [total, time, attrib] = prime_par(lower, upper)
%% prime_par returns the number of primes between lower and upper bounds
% We use lazy parallelisation and let Matlab try its best to figure things
% out. It is okay for simple scripts like this. But things become more
% complicated if we want to explicitly allocate computations accross workers.

  % Get parpool info
  p = gcp();
  numWorkers = p.NumWorkers;

  %Create a counter for primes
  total = 0;

  % convert to int32 for comparison
  lower = int32(lower);
  upper = int32(upper);
  
  % Record which workers performed which iterations
  attrib = cell(numel(lower:upper),1);
  
  % start a timer to benchmark the main loop
  ticBytes(gcp);
  ticID = tic;

  %To check for prime nature, test whether any number below the value 
  %of the current number is a factor.
  %If it is a prime add a counter to 'total' otherwise move on.
  
  %The main loop.
  %Check every number between the lower and upper bounds.
  parfor (i = lower : upper, numWorkers)
    %Set a flag for prime nature
    isprime = 1; % TRUE

    % Deal with the case of Prime Numbers 1 and 2
    if i <= 1
        isprime = 0; % FALSE
    elseif i == 2
        isprime = 1; % TRUE
        
    % Now go through all other numbers
    else
        % Start at 2 and test all numbers up to the current number
        for j = 2 : i-1
            % Check if the numbers divide without remainder (i.e. are
            % factors)
            if ( mod (i, j) == 0 )
                isprime = 0; %FALSE
%                 break
            end
        end
%         isprime = ~any(mod(i,2:i-1)==0); %FALSE
    end
    
    %Now check the flag to see if we increment the counter or not
    if isprime == 1
        total = total + 1;
%         t = getCurrentTask(); attrib{i} = mod(t.ID,numWorkers);
    end

  end

  % stop the timer
  time = toc(ticID);
  tocBytes(gcp)
  
  % Note attributions
  attrib = hist([attrib{:}],0:numWorkers-1);

end